import numpy as np
from flask import Flask, request, jsonify, render_template
from joblib import load
app = Flask(__name__)
model = load("model.save")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    '''
    For rendering results on HTML GUI
    '''
    x_test = [[x for x in request.form.values()]]
    print(x_test)
    prediction = model.predict(x_test)
    print(prediction)
    output=prediction[0]
    if(output==0):
        pred="The patient is in scale 0 and perfectly okay"
    elif(output==1):
        pred="The patient is in scale 1 and he/she is ill but not very much"
    else:
        pred="The patient is in scale 2 and very much ill that he need t0 consult the doctor"
    
    return render_template('index.html', prediction_text='{}'.format(pred))

'''@app.route('/predict_api',methods=['POST'])
def predict_api():
    
   # For direct API calls trought request

    data = request.get_json(force=True)
    prediction = model.y_predict([np.array(list(data.values()))])

    output = prediction[0]
    return jsonify(output)'''

if __name__ == "__main__":
    app.run(debug=True)
